// Copyright 1998-2017 Epic Games, Inc. All Rights Reserved.

#include "TwoPlayer3.h"


IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, TwoPlayer3, "TwoPlayer3" );
 